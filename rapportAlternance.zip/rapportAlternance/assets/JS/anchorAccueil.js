
let accueil = document.getElementById("accueil");
let anchors = document.getElementsByClassName("header-anchor");
console.log(accueil);
let anchor = anchors[0]
function visible() {
    anchor.style.visibility = 'visible';
}

function hidden() {
    anchor.style.visibility = 'hidden';
}
accueil.addEventListener("mouseenter", visible);
accueil.addEventListener("mouseleave", hidden);
