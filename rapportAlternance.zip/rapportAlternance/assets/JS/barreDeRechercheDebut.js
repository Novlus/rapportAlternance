
// let submit = document.getElementById('submit')
// let contents;
// let doc = document.body.innerHTML;
// console.log(submit)
// submit.addEventListener('click', function e() {
//     console.log(document.body.innerHTML)
//     let searchBare = document.getElementById('searchBare').value;
//     let value = searchBare;
//     let text = doc.split(' ');
//     let compteur = 0
//     function getMot(mot) {
//         compteur = 0;
//         for (let j = 0; j < text.length; j++) {
//             if (mot == text[j]) {
//                 compteur++;
//             }
//         }
//         return compteur;
//     }
//     console.log(value + ': est répété ' + getMot(value) + ' fois \n')
//     document.body.innerHTML = doc.replace(value, '<mark>' + value + '</mark>');
//     // document.getElementById('searchBare').value = "";

// })





